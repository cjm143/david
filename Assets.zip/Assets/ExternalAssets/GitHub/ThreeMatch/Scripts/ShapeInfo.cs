﻿using UnityEngine;
using System.Collections;

public class ShapeInfo
{
    public int Column { get; set; }
    public int Row { get; set; }
}
