using System.Collections.Generic;
using System.Linq;
using com.kleberswf.lib.core;

public class GameManager : Singleton<GameManager>
{
    private List<InitStarter> inits = new();

    public void AddInitStarter(InitStarter init)
    {
        if (init == null)
            return;

        inits.Add(init);
    }


    private void Start()
    {
        inits.OrderBy(init => init.Priority);

        foreach (InitStarter init in inits)
        {
            init.Init();
        }
    }
}
