using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Extentions
{
    public static class Utilities
    {
        /*
            Example:

            public static Vector3 CalculatePositionOnCircle(Vector3 _center, float _angle, float _radius)
            {
                _angle = 270 - _angle;
                float angleRad = _angle * Mathf.Deg2Rad; // 도에서 라디안으로 변환
                float x = _center.x + _radius * Mathf.Cos(angleRad);
                float z = _center.z + _radius * Mathf.Sin(angleRad);

                return new Vector3(x, _center.y, z); // Y 좌표는 필요에 따라 조정
            }
        */
    }
}
