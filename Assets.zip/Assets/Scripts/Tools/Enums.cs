namespace Enums
{


    /*
    Example:
    
    public enum Stance
    {
        None = -1,
        Middle,
        Left,
        Right,
        Up
    }
    */
}
