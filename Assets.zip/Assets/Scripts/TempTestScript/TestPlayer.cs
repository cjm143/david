public class TestPlayer : InitStarter
{
}
