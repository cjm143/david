public class TestPlayerFunction : InitChild
{

    public override void Init(InitStarter origin)
    {
        base.Init(origin);

        origin.GetChild<TestPlayerSpeak>()?.Speak();
    }
}
